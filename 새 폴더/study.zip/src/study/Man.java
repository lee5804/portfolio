package study;

public class Man {

	String name;
	int hp = 100;
	
	public Man(String n) {
			name = n;
		
	}
	
	public void attack(Girl g) {
		
		Study01.lbl.setText(name+"는" + g.name + "에게 고백했다.");
		g.favor = g.favor - 30;
	
		if(g.favor<1) {
			Study01.lbl.setText(g.name +"는 고백을 받아줬다.\n");
			Study01.lbl2.setText("");
		}else {
			Study01.lbl.setText("현재"+ g.name + "의 호감도는" +g.favor +"이다\n");
			
			
		}
		}
	
	
	
	}
