//Girl.java

package study;

import javax.swing.JOptionPane;

public class Girl {
	
	String name;
	int favor = 100; //호감도지수
	
	//생성자
	public Girl(String n) {
		
		name = n;
		
	}
	
	//고백공격
	public void attack(Man m) {
		if (favor > 0) {
			
			m.hp=m.hp -5;
			
			if(m.hp< 1) {
				JOptionPane.showMessageDialog(null, "연애에 실패했다.");
				System.exit(0);
			}
			Study01.lbl2.setText("현재 " + m.name + "의 용기는 " + m.hp + "이다\n");
		}
		
	}
	
}
